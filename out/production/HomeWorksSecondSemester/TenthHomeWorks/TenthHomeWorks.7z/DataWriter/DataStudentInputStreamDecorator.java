package TenthHomeWorks.DataWriter;

import SecondHomeWorks.First.Student;

import java.io.*;
import java.nio.ByteBuffer;

public class DataStudentInputStreamDecorator extends InputStream {
    DataInputStream inputStream;

    public DataStudentInputStreamDecorator(InputStream inputStream) {
        this.inputStream = new DataInputStream(inputStream);
    }

    public Student readStudent() throws IOException{
        int point = inputStream.readInt();
        byte nameLength = inputStream.readByte();
        String name = "";
        for(int j = 0;j < nameLength;j++){
            name += inputStream.readChar();
        }
        char gender = inputStream.readChar();
        short date = inputStream.readShort();

        return new Student(point,name,gender,date);
    }

    @Override
    public int read() throws IOException {
        return inputStream.read();
    }

    public static void main(String[] args) {
        try(DataStudentInputStreamDecorator in = new DataStudentInputStreamDecorator(new FileInputStream("D:\\input.txt"));) {
            Student st = in.readStudent();
            System.out.println(st.getPoints());
            System.out.println(st.getName());
            System.out.println(st.getGender());
            System.out.println(st.getBithDate());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
